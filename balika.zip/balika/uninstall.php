<?php
/**
 * اجرا می‌شود فقط زمانی که پلاگین از طریق پنل وردپرس به‌طور کامل حذف شود (نه صرفاً غیرفعال شود)
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$options = get_option( 'bon_settings', [] );

// پیش‌فرض امن: اگر ادمین صراحتاً این گزینه را فعال نکرده باشد، هیچ داده‌ای پاک نمی‌شود
if ( empty( $options['delete_data_on_uninstall'] ) ) {
    return;
}

global $wpdb;

// حذف جدول‌های اختصاصی پلاگین
$tables = [
    $wpdb->prefix . 'bon_logs',
    $wpdb->prefix . 'bon_queue',
    $wpdb->prefix . 'bon_customer_links',
    $wpdb->prefix . 'bon_cart_snapshots',
];
foreach ( $tables as $table ) {
    $wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
}

// حذف تنظیمات
delete_option( 'bon_settings' );

// حذف رویدادهای زمان‌بندی‌شده کرون
wp_clear_scheduled_hook( 'bon_daily_report_event' );
wp_clear_scheduled_hook( 'bon_weekly_report_event' );
wp_clear_scheduled_hook( 'bon_process_queue_event' );
wp_clear_scheduled_hook( 'bon_check_abandoned_carts_event' );
wp_clear_scheduled_hook( 'bon_payment_reminder_event' );
wp_clear_scheduled_hook( 'bon_cleanup_cart_snapshots_event' );

// حذف متادیتاهای سفارش که این پلاگین روی سفارش‌ها ذخیره کرده بود
$wpdb->query(
    "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN (
        '_bon_new_order_notified', '_bon_customer_notified', '_bon_sent_messages',
        '_bon_tracking_code', '_bon_courier_name', '_bon_tracking_url', '_bon_payment_reminder_sent'
    )"
);
