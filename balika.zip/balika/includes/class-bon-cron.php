<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * کلاس کرون - ارسال خودکار گزارش‌ها طبق زمان‌بندی و پردازش دوره‌ای صف ارسال
 */
class Bale_Order_Notifier_Cron {

    private static $instance = null;

    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'bon_daily_report_event', [ $this, 'send_daily_report' ] );
        add_action( 'bon_weekly_report_event', [ $this, 'send_weekly_report' ] );
        add_filter( 'cron_schedules', [ $this, 'add_custom_schedules' ] );
    }

    public function add_custom_schedules( $schedules ) {
        $schedules['bon_five_minutes'] = [
            'interval' => 5 * 60,
            'display'  => __( 'هر ۵ دقیقه (صف ارسال بله نوتیفای)', 'balika' ),
        ];
        return $schedules;
    }

    public function send_daily_report() {
        if ( ! bon_get_option( 'daily_report_enabled', false ) ) {
            return;
        }
        self::send_report_now( 'today' );

        if ( bon_get_option( 'auto_stock_reports', false ) ) {
            self::send_report_now( 'low_stock' );
            self::send_report_now( 'out_of_stock' );
        }
    }

    public function send_weekly_report() {
        if ( ! bon_get_option( 'weekly_report_enabled', false ) ) {
            return;
        }
        self::send_report_now( 'this_week' );
        self::send_report_now( 'top_products' );
    }

    /**
     * ارسال فوری یک گزارش مشخص به همه مقاصد فعال (برای دکمه ارسال دستی و کرون)
     */
    public static function send_report_now( $type ) {
        $message = Bale_Order_Notifier_Reports::generate( $type );
        return Bale_Order_Notifier_Dispatcher::broadcast( $message );
    }
}
