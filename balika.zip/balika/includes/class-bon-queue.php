<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * کلاس صف ارسال - در صورت شکست ارسال پیام (قطعی شبکه، خطای موقت سرور و...)،
 * پیام در جدول صف ذخیره شده و توسط کرون هر ۵ دقیقه با backoff نمایی دوباره تلاش می‌شود.
 * پس از ۵ تلاش ناموفق، پیام به‌عنوان dead-letter علامت‌گذاری و دیگر تلاش نمی‌شود.
 */
class Bale_Order_Notifier_Queue {

    const MAX_ATTEMPTS = 5;

    private static $instance = null;

    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'bon_process_queue_event', [ $this, 'process_queue' ] );
    }

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . 'bon_queue';
    }

    public static function create_table() {
        global $wpdb;
        $table_name      = self::table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            platform VARCHAR(20) NOT NULL,
            method VARCHAR(50) NOT NULL,
            payload LONGTEXT NOT NULL,
            attempts INT UNSIGNED NOT NULL DEFAULT 0,
            next_attempt DATETIME NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * افزودن پیام ناموفق به صف
     */
    public static function enqueue( $platform, $method, $params ) {
        global $wpdb;
        $wpdb->insert( self::table_name(), [
            'platform'     => $platform,
            'method'       => $method,
            'payload'      => wp_json_encode( $params ),
            'attempts'     => 0,
            'next_attempt' => current_time( 'mysql' ),
            'status'       => 'pending',
            'created_at'   => current_time( 'mysql' ),
        ] );
    }

    /**
     * پردازش صف - اجرا می‌شود توسط کرون هر ۵ دقیقه
     */
    public function process_queue() {
        global $wpdb;
        $table = self::table_name();
        $now   = current_time( 'mysql' );

        $items = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE status = %s AND next_attempt <= %s LIMIT 20",
            'pending', $now
        ) );

        if ( empty( $items ) ) {
            return;
        }

        foreach ( $items as $item ) {
            $params = json_decode( $item->payload, true );
            $api    = new Bale_Order_Notifier_API( $item->platform );

            // فراخوانی مستقیم متد خصوصی request از طریق متد عمومی موجود بر اساس method
            $result = $this->call_method( $api, $item->method, $params );

            if ( $result ) {
                $wpdb->update( $table, [ 'status' => 'sent' ], [ 'id' => $item->id ] );
                Bale_Order_Notifier_Logger::log( 'success', "پیام صف (#{$item->id}) با موفقیت مجدداً ارسال شد." );
            } else {
                $attempts = (int) $item->attempts + 1;
                if ( $attempts >= self::MAX_ATTEMPTS ) {
                    $wpdb->update( $table, [ 'attempts' => $attempts, 'status' => 'dead-letter' ], [ 'id' => $item->id ] );
                    Bale_Order_Notifier_Logger::log( 'error', "پیام صف (#{$item->id}) پس از {$attempts} تلاش ناموفق، بایگانی شد." );
                } else {
                    // تاخیر نمایی: ۵، ۱۰، ۲۰، ۴۰ دقیقه
                    $delay_minutes = 5 * pow( 2, $attempts - 1 );
                    $next          = date( 'Y-m-d H:i:s', strtotime( $now ) + ( $delay_minutes * MINUTE_IN_SECONDS ) );
                    $wpdb->update( $table, [ 'attempts' => $attempts, 'next_attempt' => $next ], [ 'id' => $item->id ] );
                }
            }
        }
    }

    private function call_method( $api, $method, $params ) {
        switch ( $method ) {
            case 'sendMessage':
                $buttons = [];
                if ( ! empty( $params['reply_markup'] ) ) {
                    $decoded = json_decode( $params['reply_markup'], true );
                    $buttons = $decoded['inline_keyboard'] ?? [];
                }
                return $api->send_message( $params['chat_id'], $params['text'], $buttons, false );
            default:
                return false;
        }
    }

    public static function get_queue_stats() {
        global $wpdb;
        $table = self::table_name();
        return [
            'pending'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'pending'" ),
            'dead_letter' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'dead-letter'" ),
            'sent'        => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'sent'" ),
        ];
    }
}

if ( ! defined( 'MINUTE_IN_SECONDS' ) ) {
    define( 'MINUTE_IN_SECONDS', 60 );
}
