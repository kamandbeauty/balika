<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * کلاس وبهوک - دریافت آپدیت از بله/تلگرام
 *
 * دو نوع کاربر کاملاً متفاوت با این بات صحبت می‌کنند:
 * ۱) ادمین (chat_id هایی که در تنظیمات پلتفرم ثبت شده‌اند) → دسترسی به گزارش‌ها و دکمه‌های مدیریتی
 * ۲) مشتری (هرکس دیگری) → فقط امکان اتصال حساب و دریافت کد رهگیری سفارش خودش، هیچ گزارش یا داده‌ای از سایت نمی‌بیند
 */
class Bale_Order_Notifier_Webhook {

    private static $instance = null;

    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', [ $this, 'maybe_handle_webhook' ] );
    }

    public function maybe_handle_webhook() {
        if ( ! isset( $_GET[ BON_WEBHOOK_QUERY_VAR ] ) ) {
            return;
        }

        if ( ! $this->is_valid_webhook_request() ) {
            Bale_Order_Notifier_Logger::log( 'error', 'درخواست وبهوک با توکن مخفی نامعتبر یا بدون توکن رد شد.' );
            status_header( 403 );
            wp_send_json_error( [ 'ok' => false, 'error' => 'invalid secret' ], 403 );
            exit;
        }

        $platform = isset( $_GET['platform'] ) && $_GET['platform'] === 'telegram' ? 'telegram' : 'bale';

        $raw_input = file_get_contents( 'php://input' );
        $update    = json_decode( $raw_input, true );

        if ( empty( $update ) ) {
            wp_send_json_success( [ 'ok' => true ] );
            return;
        }

        if ( isset( $update['message']['chat']['id'] ) ) {
            $this->handle_incoming_message( $platform, $update['message'] );
        }

        if ( isset( $update['callback_query'] ) ) {
            $this->handle_callback_query( $platform, $update['callback_query'] );
        }

        wp_send_json_success( [ 'ok' => true ] );
        exit;
    }

    /**
     * بررسی می‌کند آیا درخواست دریافتی حاوی توکن مخفی صحیح در پارامتر secret است یا نه
     */
    private function is_valid_webhook_request() {
        $expected_secret = bon_get_webhook_secret();
        $provided_secret  = isset( $_GET['secret'] ) ? sanitize_text_field( $_GET['secret'] ) : '';
        return ! empty( $expected_secret ) && hash_equals( $expected_secret, $provided_secret );
    }

    /**
     * آیا این chat_id متعلق به یکی از ادمین‌های تنظیم‌شده در پنل است؟
     * تمام دستورات گزارش‌گیری و مدیریتی فقط برای این لیست مجاز است.
     */
    private function is_admin_chat( $platform, $chat_id ) {
        $admin_ids   = (array) bon_get_option( $platform . '_chat_ids', [] );
        $chat_id_str = (string) $chat_id;
        foreach ( $admin_ids as $id ) {
            if ( trim( (string) $id ) === $chat_id_str ) {
                return true;
            }
        }
        return false;
    }

    /**
     * پردازش پیام متنی دریافتی - مسیردهی جداگانه برای ادمین و مشتری
     */
    private function handle_incoming_message( $platform, $message ) {
        $chat_id = $message['chat']['id'];
        $name    = $message['chat']['first_name'] ?? ( $message['from']['first_name'] ?? '' );
        $text    = trim( $message['text'] ?? '' );

        $is_admin = $this->is_admin_chat( $platform, $chat_id );
        Bale_Order_Notifier_Logger::log( 'info', "پیام دریافتی ({$platform}) از chat_id: {$chat_id} ({$name}) - " . ( $is_admin ? 'ادمین' : 'مشتری' ) );

        // --- دیپ‌لینک اتصال مشتری: /start order123 (مخصوص مشتری، مستقل از نقش ادمین) ---
        if ( preg_match( '/^\/start(?:\s+|@\S+\s+)?order(\d+)$/i', $text, $m ) ) {
            $this->handle_customer_start_link( $platform, $chat_id, (int) $m[1] );
            return;
        }

        // --- ارسال شماره تلفن توسط کاربر: جست‌وجوی سفارش و پاسخ با کد رهگیری/وضعیت ---
        if ( class_exists( 'Bale_Order_Notifier_Customer_Store' ) && Bale_Order_Notifier_Customer_Store::looks_like_phone( $text ) ) {
            if ( class_exists( 'Bale_Order_Notifier_Customer_Hooks' ) ) {
                Bale_Order_Notifier_Customer_Hooks::instance()->handle_phone_message( $platform, $chat_id, $text );
            }
            return;
        }

        // --- دستورات مدیریتی: فقط برای ادمین ---
        if ( $is_admin && in_array( $text, [ '/reports', '/گزارش', '/گزارشات', '/start', '/help', '/راهنما' ], true ) ) {
            $this->send_report_menu( $platform, $chat_id );
            return;
        }

        // --- پیام خوش‌آمد برای مشتری (غیر ادمین) در صورت /start یا /help ---
        if ( ! $is_admin && in_array( $text, [ '/start', '/help', '/راهنما' ], true ) ) {
            $api = new Bale_Order_Notifier_API( $platform );
            $api->send_message( $chat_id, 'سلام! 👋 برای پیگیری سفارش، شماره موبایلی که هنگام خرید ثبت کردید رو همینجا برام بفرستید.' );
            return;
        }

        // سایر پیام‌های نامرتبط از سمت مشتری نادیده گرفته می‌شوند (بدون افشای هیچ داده‌ای)
    }

    /**
     * پردازش دیپ‌لینک اتصال مشتری: /start order{id}
     * شماره تلفن سفارش را استخراج و به chat_id متصل می‌کند، سپس بلافاصله جزئیات همان سفارش را می‌فرستد.
     */
    private function handle_customer_start_link( $platform, $chat_id, $order_id ) {
        $api   = new Bale_Order_Notifier_API( $platform );
        $order = wc_get_order( $order_id );

        if ( ! $order ) {
            $api->send_message( $chat_id, 'سفارش یافت نشد. لطفاً شماره موبایل خود را ارسال کنید تا حساب شما متصل شود.' );
            return;
        }

        $phone = $order->get_billing_phone();
        if ( empty( $phone ) ) {
            $api->send_message( $chat_id, 'شماره تماس این سفارش ثبت نشده. لطفاً شماره موبایل خود را همینجا ارسال کنید.' );
            return;
        }

        Bale_Order_Notifier_Customer_Store::link( $phone, $platform, $chat_id );
        $api->send_message( $chat_id, '✅ حساب شما با موفقیت متصل شد. از این پس جزئیات سفارش‌ها و کد رهگیری همینجا برای شما ارسال می‌شود.' );

        // ارسال فوری جزئیات همین سفارش که از طریق آن اتصال برقرار شد
        if ( class_exists( 'Bale_Order_Notifier_Customer_Hooks' ) ) {
            Bale_Order_Notifier_Customer_Hooks::instance()->send_order_confirmation_to_customer( $order );
        }

        Bale_Order_Notifier_Logger::log( 'success', "مشتری سفارش #{$order_id} حساب {$platform} خود را متصل کرد." );
    }

    /**
     * ارسال منوی دکمه‌های شیشه‌ای گزارش‌گیری زنده (فقط برای ادمین فراخوانی می‌شود)
     */
    private function send_report_menu( $platform, $chat_id ) {
        $api  = new Bale_Order_Notifier_API( $platform );
        $rows = [];
        $row  = [];
        $i    = 0;
        foreach ( Bale_Order_Notifier_Reports::get_report_types() as $key => $label ) {
            $row[] = [ 'text' => $label, 'callback_data' => 'bon_report:' . $key ];
            $i++;
            if ( $i % 2 === 0 ) {
                $rows[] = $row;
                $row    = [];
            }
        }
        if ( ! empty( $row ) ) {
            $rows[] = $row;
        }

        $api->send_message( $chat_id, "📋 کدام گزارش را می‌خواهید؟\nروی یکی از دکمه‌های زیر بزنید:", $rows );
    }

    /**
     * پردازش کلیک روی دکمه‌های اینلاین - همه این دکمه‌ها (تغییر وضعیت سفارش، گزارش‌گیری)
     * مدیریتی هستند و فقط برای ادمین مجازند، حتی اگر داده callback_data به‌نحوی به غیر ادمین برسد.
     */
    private function handle_callback_query( $platform, $callback_query ) {
        $data       = $callback_query['data'] ?? '';
        $chat_id    = $callback_query['message']['chat']['id'] ?? null;
        $message_id = $callback_query['message']['message_id'] ?? null;
        $cb_id      = $callback_query['id'] ?? null;

        $api = new Bale_Order_Notifier_API( $platform );

        if ( ! $this->is_admin_chat( $platform, $chat_id ) ) {
            $api->answer_callback_query( $cb_id, '⛔ این بخش فقط برای مدیر فروشگاه در دسترس است.' );
            Bale_Order_Notifier_Logger::log( 'error', "تلاش دسترسی غیرمجاز به دکمه مدیریتی از chat_id: {$chat_id}" );
            return;
        }

        // --- کلیک روی دکمه تغییر وضعیت سفارش: bon_status:{new_status}:{order_id} ---
        if ( strpos( $data, 'bon_status:' ) === 0 ) {
            $parts = explode( ':', $data );
            if ( count( $parts ) !== 3 ) {
                return;
            }
            list( , $new_status, $order_id ) = $parts;

            $order = wc_get_order( (int) $order_id );
            if ( ! $order ) {
                $api->answer_callback_query( $cb_id, 'سفارش یافت نشد.' );
                return;
            }

            $order->update_status( $new_status, 'وضعیت از طریق دکمه پیام‌رسان تغییر کرد. ' );

            $status_label = wc_get_order_status_name( $new_status );
            $api->answer_callback_query( $cb_id, "وضعیت به «{$status_label}» تغییر کرد ✅" );

            if ( $chat_id && $message_id ) {
                $new_text = "✅ سفارش #{$order_id}\nوضعیت جدید: {$status_label}";
                $api->edit_message( $chat_id, $message_id, $new_text );
            }

            Bale_Order_Notifier_Logger::log( 'success', "وضعیت سفارش #{$order_id} از طریق {$platform} به {$new_status} تغییر کرد." );
            return;
        }

        // --- کلیک روی دکمه گزارش‌گیری زنده: bon_report:{type} ---
        if ( strpos( $data, 'bon_report:' ) === 0 ) {
            $type = substr( $data, strlen( 'bon_report:' ) );
            $api->answer_callback_query( $cb_id, 'در حال آماده‌سازی گزارش... ⏳' );

            $message = Bale_Order_Notifier_Reports::generate( $type );
            if ( $chat_id ) {
                $api->send_message( $chat_id, $message );
            }
            Bale_Order_Notifier_Logger::log( 'success', "گزارش '{$type}' با کلیک دکمه در {$platform} ارسال شد." );
            return;
        }
    }
}
